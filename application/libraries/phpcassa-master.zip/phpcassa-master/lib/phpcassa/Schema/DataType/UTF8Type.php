<?php
namespace phpcassa\Schema\DataType;

/**
 * Format for UTF8-encoded unicode strings.
 *
 * @package phpcassa\Schema\DataType
 */
class UTF8Type extends CassandraType { }
