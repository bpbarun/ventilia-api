<?php
namespace phpcassa\Schema\DataType;

interface Serialized {}
