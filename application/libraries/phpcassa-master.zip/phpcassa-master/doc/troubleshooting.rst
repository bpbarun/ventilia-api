Troubleshooting
===============

"A connection attempt failed because the connected party did not properly respond"
----------------------------------------------------------------------------------
This may be an issue on Windows systems: see
`here <http://ryan.rawswift.com/2010/03/29/a-connection-attempt-failed-because-the-connected-party-did-not-properly-respond/>`_
for the solution.
